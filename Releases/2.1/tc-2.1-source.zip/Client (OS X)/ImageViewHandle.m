//
//  ImageViewHandle.m
//  TuneConnect
//
//  Created by Matt Patenaude on 12/21/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import "ImageViewHandle.h"


@implementation ImageViewHandle
- (BOOL)mouseDownCanMoveWindow
{
	return YES;
}
@end
