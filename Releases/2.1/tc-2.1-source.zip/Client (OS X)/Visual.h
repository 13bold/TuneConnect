//
//  Visual.h
//  TuneConnect
//
//  Created by Matt Patenaude on 12/25/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TCObject.h"


@interface Visual : TCObject {

}

- (id)initWithProperties:(NSDictionary *)itemProperties;

@end
