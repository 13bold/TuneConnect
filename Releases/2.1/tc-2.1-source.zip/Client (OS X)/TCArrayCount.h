//
//  TCArrayCount.h
//  TuneConnect
//
//  Created by Matt Patenaude on 2/23/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TCArrayCount : NSValueTransformer {

}

@end
