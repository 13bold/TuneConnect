//
//  TCPlaylistImage.h
//  TuneConnect
//
//  Created by Matt Patenaude on 2/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TCPlaylistImage : NSValueTransformer {

}

@end
