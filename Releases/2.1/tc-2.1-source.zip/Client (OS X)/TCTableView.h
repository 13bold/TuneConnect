//
//  TCTableView.h
//  TuneConnect
//
//  Created by Matt Patenaude on 2/4/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TCTableView : NSTableView {

}

@end
