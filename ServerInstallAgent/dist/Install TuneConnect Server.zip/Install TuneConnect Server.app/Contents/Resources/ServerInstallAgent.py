# TuneConnect Server Install Agent
# Copyright (C) 2008 Matt Patenaude

from Foundation import *
from os import path, spawnv, P_NOWAIT
from shutil import copytree, move
from appscript import *
from datetime import datetime
from time import sleep

def main():
	# First, we need to open up the server settings
	prefLocation = path.expanduser("~/Library/Preferences/net.tuneconnect.Server.plist")

	if not path.exists(prefLocation):
		# Assume default values for preferences
		prefs = {'libraryExpiryTime':86400, 'password':'', 'port':4242, 'useLibraryFile':True}
	else:
		# Load into a dictionary
		prefs = NSDictionary.dictionaryWithContentsOfFile_(prefLocation)
	
	# Grab the server port
	port = prefs['port']

	# Check if the server is running
	url = NSURL.URLWithString_('http://localhost:' + str(port) + '/tc.status')
	stopUrl = NSURL.URLWithString_('http://localhost:' + str(port) + '/tc.shutdownNow')
	error = None
	result, error = NSString.stringWithContentsOfURL_encoding_error_(url, NSUTF8StringEncoding)

	if (result != "Server Running"):
		# Not running, we're good
		pass
	else:
		# Gotta' stop that server
		result, error = NSString.stringWithContentsOfURL_encoding_error_(stopUrl, NSUTF8StringEncoding)
		if (result == None) or (result == ""):
			# Success!
			pass
		else:
			print "Error: Could not stop server"
			return
	
	# If System Preferences is running, quit it
	app('System Preferences').quit()
	
	# Let's see if the preference pane exists
	paneLocation = path.expanduser("~/Library/PreferencePanes/TuneConnect Server.prefPane")
	paneExists = True
	if not path.exists(paneLocation):
		paneLocation = "/Library/PreferencePanes/TuneConnect Server.prefPane"
		if not path.exists(paneLocation):
			# No preference pane, nothing to delete :)
			paneExists = False
			paneLocation = path.expanduser("~/Library/PreferencePanes/TuneConnect Server.prefPane")
	
	# If the pane exists, get rid of it
	if paneExists:
		trashPath = path.expanduser("~/.Trash/TuneConnect Server.prefPane")
		if path.exists(trashPath):
			trashPath += datetime.now().isoformat()
		NSFileManager.defaultManager().movePath_toPath_handler_(paneLocation, trashPath, None)
	
	# Now copy the new pane to the same location
	paneLocation = path.expanduser("~/Library/PreferencePanes/TuneConnect Server.prefPane")
	NSFileManager.defaultManager().copyPath_toPath_handler_("TuneConnect Server.prefPane", paneLocation, None)
	
	# Start the server
	spawnv(P_NOWAIT, '/usr/bin/open', ["", paneLocation + '/Contents/Resources/tc-server.app'])
	sleep(3)
	
	# And finally, open the new pane :)
	spawnv(P_NOWAIT, '/usr/bin/open', ["", paneLocation])

if __name__ == '__main__':
	main()