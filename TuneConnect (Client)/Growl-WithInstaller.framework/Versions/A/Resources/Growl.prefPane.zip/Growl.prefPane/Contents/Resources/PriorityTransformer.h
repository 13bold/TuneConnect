//
//  PriorityTransformer.h
//  Growl
//
//  Created by Evan Schoenberg on 6/21/07.
//

#import <Cocoa/Cocoa.h>

@interface PriorityTransformer : NSValueTransformer {

}

@end
